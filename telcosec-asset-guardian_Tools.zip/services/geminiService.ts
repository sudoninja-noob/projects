
import { GoogleGenAI } from "@google/genai";
import { Asset } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export const getAssetIntelligence = async (asset: Asset) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a Telecom Lab Asset Expert. Analyze this asset:
      Name: ${asset.name}
      Category: ${asset.category}
      Type: ${asset.type}
      Testing Status: ${asset.testingStatus || 'N/A'}
      
      Provide a 3-sentence summary regarding security maintenance advice or expected compliance checks for this specific type of telecom equipment.`,
    });
    
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "AI insights currently unavailable.";
  }
};

export const generateAuditSummary = async (logs: any[]) => {
  try {
    const logText = logs.slice(0, 10).map(l => `${l.action} by ${l.performedBy} on ${l.timestamp}`).join('\n');
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze these recent asset logs and provide a 2-sentence security posture summary:\n${logText}`,
    });
    return response.text;
  } catch (error) {
    return "Audit summary unavailable.";
  }
};
