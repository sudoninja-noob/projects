
import React from 'react';
import { 
  LayoutDashboard, 
  Package, 
  ShieldCheck, 
  History, 
  Users,
  ShieldAlert
} from 'lucide-react';
import { Role } from './types';

export interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  roles?: Role[];
}

export const NAVIGATION_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
  { id: 'internal', label: 'Internal Assets', icon: <Package size={20} /> },
  { id: 'oem', label: 'OEM Devices', icon: <ShieldCheck size={20} /> },
  { id: 'logs', label: 'Audit Logs', icon: <History size={20} /> },
  { id: 'staff', label: 'Staff Management', icon: <Users size={20} />, roles: [Role.ADMIN] },
];

export const CATEGORIES = {
  INTERNAL: ['PC/Laptop', 'Server', 'Firewall', 'Network Switch', 'USB Token', 'Furniture', 'Lab Equipment'],
  OEM: [
    'IP Router',
    'WIFI CPE',
    'ONT',
    'OLT',
    'CCTV',
    'IOT Device',
    'Switch',
    'USB',
    'Car Play',
    'NA'
  ]
};

export const STATUS_COLORS: Record<string, string> = {
  INWARD: 'bg-green-100 text-green-800',
  IN_USE: 'bg-blue-100 text-blue-800',
  TESTING: 'bg-amber-100 text-amber-800',
  RETURNED: 'bg-slate-100 text-slate-800',
  MAINTENANCE: 'bg-orange-100 text-orange-800',
  LOST: 'bg-red-100 text-red-800',
  PASS: 'bg-green-100 text-green-800',
  FAIL: 'bg-red-100 text-red-800',
  PENDING: 'bg-slate-100 text-slate-600',
};

export const DEFAULT_SECURITY_QUESTIONS = [
  "What was the name of your first pet?",
  "In what city were you born?",
  "What is your mother's maiden name?",
  "What was the name of your first school?",
  "What is your favorite color?",
  "What was your first car?",
  "What is the name of your favorite book?",
  "Who was your childhood hero?"
];
