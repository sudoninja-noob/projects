
export enum Role {
  ADMIN = 'ADMIN',
  SECURITY_GUARD = 'SECURITY_GUARD'
}

export enum AssetType {
  INTERNAL = 'INTERNAL',
  OEM = 'OEM'
}

export enum AssetStatus {
  INWARD = 'INWARD',
  IN_USE = 'IN_USE',
  TESTING = 'TESTING',
  RETURNED = 'RETURNED',
  MAINTENANCE = 'MAINTENANCE',
  LOST = 'LOST'
}

export enum TestingStatus {
  PENDING = 'PENDING',
  IN_PROGRESS = 'IN_PROGRESS',
  PASS = 'PASS',
  FAIL = 'FAIL'
}

export interface AssetDocument {
  name: string;
  size: number;
  type: string;
  lastModified: number;
}

export interface Asset {
  id: string;
  tag: string;
  name: string;
  type: AssetType;
  category: string;
  location: string;
  status: AssetStatus;
  assignedTo?: string;
  purchaseDate?: string;
  warrantyExpiry?: string;
  condition: string;
  
  // OEM Specific
  poNumber?: string;
  poFile?: AssetDocument;
  invoiceNumber?: string;
  invoiceFile?: AssetDocument;
  challanNumber?: string;
  challanFile?: AssetDocument;
  
  testingStatus?: TestingStatus;
  oemReturnDate?: string;
  oemName?: string;
  
  // Status History / Event Tracking
  statusDate?: string;
  statusTime?: string;
  
  description?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  assetId: string;
  assetTag: string;
  action: string;
  performedBy: string;
  details: string;
}

export interface SecurityQuestion {
  question: string;
  answer: string;
}

export interface User {
  id: string;
  name: string;
  role: Role;
  username: string;
  password: string;
  profilePic?: string;
  securityQuestions: SecurityQuestion[];
}
