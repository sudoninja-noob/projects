
import { Asset, AssetType, AssetStatus, TestingStatus, AuditLogEntry } from '../types';

export const INITIAL_ASSETS: Asset[] = [
  {
    id: '1',
    tag: 'INT-001',
    name: 'Lab Workstation X1',
    type: AssetType.INTERNAL,
    category: 'PC/Laptop',
    location: 'Lab Room A',
    status: AssetStatus.IN_USE,
    assignedTo: 'John Tester',
    purchaseDate: '2023-01-15',
    condition: 'Excellent',
    description: 'High performance workstation for packet analysis.'
  },
  {
    id: '2',
    tag: 'OEM-202',
    name: 'Carrier Grade IP Router',
    type: AssetType.OEM,
    category: 'IP Router',
    location: 'Rack 4',
    status: AssetStatus.TESTING,
    oemName: 'Huawei Tech',
    poNumber: 'PO-98765',
    testingStatus: TestingStatus.IN_PROGRESS,
    oemReturnDate: '2024-12-31',
    condition: 'New',
    description: 'Evaluation unit for core network protocol testing.'
  },
  {
    id: '3',
    tag: 'INT-003',
    name: 'Cisco Lab Firewall',
    type: AssetType.INTERNAL,
    category: 'Firewall',
    location: 'Lab Room B',
    status: AssetStatus.INWARD,
    purchaseDate: '2022-05-10',
    condition: 'Good',
    description: 'Main perimeter firewall for testing subnets.'
  }
];

export const INITIAL_LOGS: AuditLogEntry[] = [
  {
    id: 'l1',
    timestamp: new Date().toISOString(),
    assetId: '2',
    assetTag: 'OEM-202',
    action: 'CHECK_IN',
    performedBy: 'Security Officer Smith',
    details: 'Received from OEM via courier. Condition verified.'
  }
];
