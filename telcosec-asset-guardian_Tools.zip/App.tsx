
import React, { useState } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import AssetTable from './components/AssetTable';
import AssetModal from './components/AssetModal';
import Login from './components/Login';
import StaffManagement from './components/StaffManagement';
import { Asset, AssetType, AssetStatus, AuditLogEntry, User, Role } from './types';
import { INITIAL_ASSETS, INITIAL_LOGS } from './store/mockData';
import { Plus, History } from 'lucide-react';

const INITIAL_USERS: User[] = [
  { 
    id: 'admin-1', 
    name: 'Alice Administrator', 
    role: Role.ADMIN,
    username: 'admin',
    password: 'admin123',
    profilePic: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alice',
    securityQuestions: [
      { question: "What was the name of your first pet?", answer: "Buddy" },
      { question: "In what city were you born?", answer: "New York" },
      { question: "What is your mother's maiden name?", answer: "Smith" },
      { question: "What was the name of your first school?", answer: "Lincoln" },
      { question: "What is your favorite color?", answer: "Blue" }
    ]
  },
  { 
    id: 'guard-1', 
    name: 'George Guard', 
    role: Role.SECURITY_GUARD,
    username: 'guard',
    password: 'guard123',
    profilePic: 'https://api.dicebear.com/7.x/avataaars/svg?seed=George',
    securityQuestions: [
      { question: "What was the name of your first pet?", answer: "Max" },
      { question: "In what city were you born?", answer: "London" },
      { question: "What is your mother's maiden name?", answer: "Jones" },
      { question: "What was the name of your first school?", answer: "Central" },
      { question: "What is your favorite color?", answer: "Green" }
    ]
  }
];

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [assets, setAssets] = useState<Asset[]>(INITIAL_ASSETS);
  const [logs, setLogs] = useState<AuditLogEntry[]>(INITIAL_LOGS);
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<Asset | null>(null);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  const addLog = (assetId: string, assetTag: string, action: string, details: string) => {
    if (!currentUser) return;
    const newEntry: AuditLogEntry = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
      assetId,
      assetTag,
      action,
      performedBy: currentUser.name,
      details
    };
    setLogs(prev => [newEntry, ...prev]);
  };

  const handleSaveAsset = (assetData: Partial<Asset>) => {
    if (editingAsset) {
      setAssets(prev => prev.map(a => a.id === editingAsset.id ? { ...a, ...assetData } as Asset : a));
      addLog(editingAsset.id, assetData.tag || '', 'UPDATE', `Updated asset information.`);
    } else {
      const newAsset: Asset = {
        ...assetData,
        id: Math.random().toString(36).substr(2, 9),
      } as Asset;
      setAssets(prev => [...prev, newAsset]);
      addLog(newAsset.id, newAsset.tag, 'CREATE', `Created new ${newAsset.type} asset in INWARD status.`);
    }
    setIsModalOpen(false);
    setEditingAsset(null);
  };

  const handleDeleteAsset = (id: string) => {
    const asset = assets.find(a => a.id === id);
    if (!asset) return;
    if (window.confirm(`Are you sure you want to delete ${asset.name}?`)) {
      setAssets(prev => prev.filter(a => a.id !== id));
      addLog(id, asset.tag, 'DELETE', `Deleted asset from system.`);
    }
  };

  const handleCheckInOut = (asset: Asset) => {
    const nextStatus = asset.status === AssetStatus.INWARD ? AssetStatus.IN_USE : AssetStatus.INWARD;
    setAssets(prev => prev.map(a => a.id === asset.id ? { ...a, status: nextStatus } : a));
    addLog(asset.id, asset.tag, nextStatus === AssetStatus.IN_USE ? 'CHECK_OUT' : 'CHECK_IN', `Changed status to ${nextStatus}.`);
  };

  const handleAddUser = (user: User) => {
    setUsers(prev => [...prev, user]);
  };

  const handleUpdateUser = (updatedUser: User) => {
    setUsers(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
    if (currentUser?.id === updatedUser.id) {
      setCurrentUser(updatedUser);
    }
  };

  const handleDeleteUser = (id: string) => {
    if (id === currentUser?.id) {
      alert("You cannot delete your own account.");
      return;
    }
    if (window.confirm("Are you sure you want to revoke system access for this staff member?")) {
      setUsers(prev => prev.filter(u => u.id !== id));
    }
  };

  if (!currentUser) {
    return <Login onLogin={handleLogin} users={users} />;
  }

  const canManageAssets = currentUser.role === Role.ADMIN || currentUser.role === Role.SECURITY_GUARD;

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard assets={assets} logs={logs} />;
      case 'internal':
        return (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-2xl font-black text-slate-900 tracking-tight">Internal Assets</h3>
                <p className="text-slate-500 text-sm font-medium">Manage lab-owned IT and non-IT hardware</p>
              </div>
              {canManageAssets && (
                <button 
                  onClick={() => { setEditingAsset(null); setIsModalOpen(true); }}
                  className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-2xl font-bold shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all active:scale-95"
                >
                  <Plus size={20} />
                  <span>Add Asset</span>
                </button>
              )}
            </div>
            <AssetTable 
              assets={assets} 
              type={AssetType.INTERNAL} 
              userRole={currentUser.role}
              onEdit={(a) => { setEditingAsset(a); setIsModalOpen(true); }}
              onDelete={handleDeleteAsset}
              onCheckInOut={handleCheckInOut}
              onStatusChange={() => {}}
            />
          </div>
        );
      case 'oem':
        return (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-2xl font-black text-slate-900 tracking-tight">OEM Testing Devices</h3>
                <p className="text-slate-500 text-sm font-medium">Track equipment received from vendors for evaluation</p>
              </div>
              {canManageAssets && (
                <button 
                  onClick={() => { setEditingAsset(null); setIsModalOpen(true); }}
                  className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-2xl font-bold shadow-xl shadow-blue-500/20 hover:bg-blue-700 transition-all active:scale-95"
                >
                  <Plus size={20} />
                  <span>Add OEM Device</span>
                </button>
              )}
            </div>
            <AssetTable 
              assets={assets} 
              type={AssetType.OEM} 
              userRole={currentUser.role}
              onEdit={(a) => { setEditingAsset(a); setIsModalOpen(true); }}
              onDelete={handleDeleteAsset}
              onCheckInOut={handleCheckInOut}
              onStatusChange={() => {}}
            />
          </div>
        );
      case 'logs':
        return (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div>
              <h3 className="text-2xl font-black text-slate-900 tracking-tight">Audit Trail</h3>
              <p className="text-slate-500 text-sm font-medium">Immutable traceability of all system interactions</p>
            </div>
            <div className="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="px-8 py-5 text-xs font-bold text-slate-400 uppercase tracking-widest">Timestamp</th>
                      <th className="px-8 py-5 text-xs font-bold text-slate-400 uppercase tracking-widest">Asset Tag</th>
                      <th className="px-8 py-5 text-xs font-bold text-slate-400 uppercase tracking-widest">Action</th>
                      <th className="px-8 py-5 text-xs font-bold text-slate-400 uppercase tracking-widest">Operator</th>
                      <th className="px-8 py-5 text-xs font-bold text-slate-400 uppercase tracking-widest">Event Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {logs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-8 py-5 text-xs text-slate-400 font-mono font-bold">
                          {new Date(log.timestamp).toLocaleString()}
                        </td>
                        <td className="px-8 py-5">
                          <span className="font-bold text-slate-900">{log.assetTag}</span>
                        </td>
                        <td className="px-8 py-5">
                          <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider ${
                            log.action.includes('DELETE') ? 'bg-red-50 text-red-600' : 
                            log.action.includes('CREATE') ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'
                          }`}>
                            {log.action}
                          </span>
                        </td>
                        <td className="px-8 py-5 text-sm font-bold text-slate-700">{log.performedBy}</td>
                        <td className="px-8 py-5 text-sm text-slate-500 font-medium">{log.details}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );
      case 'staff':
        return (
          <StaffManagement 
            users={users} 
            onAddUser={handleAddUser} 
            onUpdateUser={handleUpdateUser}
            onDeleteUser={handleDeleteUser} 
          />
        );
      default:
        return null;
    }
  };

  return (
    <Layout 
      activeTab={activeTab} 
      setActiveTab={setActiveTab} 
      currentUser={currentUser} 
      onLogout={handleLogout}
    >
      {renderContent()}
      
      <AssetModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveAsset}
        initialData={editingAsset}
        defaultType={activeTab === 'oem' ? AssetType.OEM : AssetType.INTERNAL}
      />

      {currentUser.role === Role.SECURITY_GUARD && activeTab !== 'logs' && (
        <div className="fixed bottom-8 right-8">
          <button 
            onClick={() => setActiveTab('logs')}
            className="flex items-center gap-3 px-6 py-4 bg-slate-900 text-white rounded-2xl shadow-2xl hover:bg-black hover:scale-105 active:scale-95 transition-all duration-300"
          >
            <History size={24} className="text-blue-400" />
            <span className="font-bold text-sm uppercase tracking-widest">Incident History</span>
          </button>
        </div>
      )}
    </Layout>
  );
};

export default App;
