
import React, { useState, useEffect, useRef } from 'react';
import { Asset, AssetType, AssetStatus, TestingStatus, AssetDocument } from '../types';
import { CATEGORIES } from '../constants';
import { X, FileText, Upload, Trash2, CheckCircle2, Calendar, Clock, ShieldCheck } from 'lucide-react';

interface AssetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (asset: Partial<Asset>) => void;
  initialData?: Asset | null;
  defaultType: AssetType;
}

const AssetModal: React.FC<AssetModalProps> = ({ isOpen, onClose, onSave, initialData, defaultType }) => {
  const [formData, setFormData] = useState<Partial<Asset>>({
    type: defaultType,
    status: AssetStatus.INWARD,
    condition: 'Excellent'
  });

  const poRef = useRef<HTMLInputElement>(null);
  const invRef = useRef<HTMLInputElement>(null);
  const chaRef = useRef<HTMLInputElement>(null);
  const internalInvRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (initialData) setFormData(initialData);
    else {
      // Set default inward date/time for new entries
      const now = new Date();
      const dateStr = now.toISOString().split('T')[0];
      const timeStr = now.toTimeString().split(' ')[0].substring(0, 5);
      setFormData({ 
        type: defaultType, 
        status: AssetStatus.INWARD, 
        condition: 'Excellent',
        statusDate: dateStr,
        statusTime: timeStr
      });
    }
  }, [initialData, defaultType, isOpen]);

  if (!isOpen) return null;

  const categories = formData.type === AssetType.INTERNAL ? CATEGORIES.INTERNAL : CATEGORIES.OEM;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: 'poFile' | 'invoiceFile' | 'challanFile') => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData({
        ...formData,
        [field]: {
          name: file.name,
          size: file.size,
          type: file.type,
          lastModified: file.lastModified
        }
      });
    }
  };

  const removeFile = (field: 'poFile' | 'invoiceFile' | 'challanFile') => {
    setFormData({ ...formData, [field]: undefined });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  // Show status date/time for both Internal and OEM when in Inward, Maintenance, Returned, or Lost
  const showStatusDateTime = [
    AssetStatus.INWARD,
    AssetStatus.MAINTENANCE,
    AssetStatus.RETURNED,
    AssetStatus.LOST
  ].includes(formData.status as AssetStatus);

  const getStatusLabel = () => {
    if (formData.status === AssetStatus.INWARD) return "Inward Date";
    return `${formData.status?.replace('_', ' ')} Date`;
  };

  const FileUploadField = ({ 
    label, 
    numberField, 
    fileField, 
    placeholder, 
    inputRef 
  }: { 
    label: string, 
    numberField: keyof Asset, 
    fileField: 'poFile' | 'invoiceFile' | 'challanFile', 
    placeholder: string,
    inputRef: React.RefObject<HTMLInputElement>
  }) => (
    <div className="space-y-2">
      <label className="text-[10px] font-bold text-slate-400 uppercase">{label}</label>
      <div className="space-y-2">
        <input
          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
          value={(formData[numberField] as string) || ''}
          onChange={(e) => setFormData({ ...formData, [numberField]: e.target.value })}
          placeholder={placeholder}
        />
        
        {!formData[fileField] ? (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="w-full flex items-center justify-center gap-2 py-2 border-2 border-dashed border-slate-200 rounded-lg text-slate-400 hover:border-blue-400 hover:text-blue-500 transition-all text-xs font-medium"
          >
            <Upload size={14} />
            Upload Document
            <input 
              type="file" 
              ref={inputRef} 
              className="hidden" 
              onChange={(e) => handleFileChange(e, fileField)} 
            />
          </button>
        ) : (
          <div className="flex items-center justify-between bg-blue-50 border border-blue-100 p-2 rounded-lg">
            <div className="flex items-center gap-2 overflow-hidden">
              <CheckCircle2 size={14} className="text-blue-500 shrink-0" />
              <span className="text-[10px] font-medium text-blue-700 truncate">{(formData[fileField] as AssetDocument).name}</span>
            </div>
            <button 
              type="button" 
              onClick={() => removeFile(fileField)} 
              className="text-slate-400 hover:text-red-500 transition-colors"
            >
              <Trash2 size={14} />
            </button>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <h3 className="text-xl font-bold text-slate-900">{initialData ? 'Edit Asset' : 'Add New Asset'}</h3>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 rounded-lg transition-colors">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase">Asset Tag</label>
              <input
                required
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                value={formData.tag || ''}
                onChange={(e) => setFormData({ ...formData, tag: e.target.value })}
                placeholder="TAG-000"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase">Asset Name</label>
              <input
                required
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                value={formData.name || ''}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Enter asset name"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase">Category</label>
              <select
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                value={formData.category || ''}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              >
                <option value="">Select Category</option>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase">Status</label>
              <select
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as AssetStatus })}
              >
                {Object.values(AssetStatus).map(s => <option key={s} value={s}>{s === AssetStatus.INWARD ? 'Inward' : s.replace('_', ' ')}</option>)}
              </select>
            </div>
          </div>

          {/* Conditional Date and Time for Inward/Maintenance/etc. */}
          {showStatusDateTime && (
            <div className="grid grid-cols-2 gap-4 p-4 bg-blue-50/50 border border-blue-100 rounded-2xl animate-in fade-in slide-in-from-top-2">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-blue-600 uppercase flex items-center gap-1 ml-1">
                  <Calendar size={12} /> {getStatusLabel()}
                </label>
                <input
                  type="date"
                  required
                  className="w-full px-4 py-2 bg-white border border-blue-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 font-medium"
                  value={formData.statusDate || ''}
                  onChange={(e) => setFormData({ ...formData, statusDate: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-blue-600 uppercase flex items-center gap-1 ml-1">
                  <Clock size={12} /> Event Time
                </label>
                <input
                  type="time"
                  required
                  className="w-full px-4 py-2 bg-white border border-blue-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 font-medium"
                  value={formData.statusTime || ''}
                  onChange={(e) => setFormData({ ...formData, statusTime: e.target.value })}
                />
              </div>
            </div>
          )}

          {formData.type === AssetType.INTERNAL ? (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-500 uppercase">Assigned To</label>
                  <input
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                    value={formData.assignedTo || ''}
                    onChange={(e) => setFormData({ ...formData, assignedTo: e.target.value })}
                    placeholder="Employee name"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-500 uppercase">Location</label>
                  <input
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                    value={formData.location || ''}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="Lab Room/Rack"
                  />
                </div>
              </div>

              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-4">
                <div className="flex items-center gap-2 mb-2">
                  <FileText size={16} className="text-indigo-600" />
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Purchase & Warranty Documentation</span>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1">
                        <Calendar size={12} /> Purchase Date
                      </label>
                      <input
                        type="date"
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none"
                        value={formData.purchaseDate || ''}
                        onChange={(e) => setFormData({ ...formData, purchaseDate: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1">
                        <ShieldCheck size={12} /> Warranty Expiry
                      </label>
                      <input
                        type="date"
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none"
                        value={formData.warrantyExpiry || ''}
                        onChange={(e) => setFormData({ ...formData, warrantyExpiry: e.target.value })}
                      />
                    </div>
                  </div>
                  <FileUploadField 
                    label="Invoice Upload" 
                    numberField="invoiceNumber" 
                    fileField="invoiceFile" 
                    placeholder="INV-XXXX"
                    inputRef={internalInvRef}
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-500 uppercase">OEM Name</label>
                  <input
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                    value={formData.oemName || ''}
                    onChange={(e) => setFormData({ ...formData, oemName: e.target.value })}
                    placeholder="e.g. Ericsson, Huawei"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-500 uppercase">Expected Return Date</label>
                  <input
                    type="date"
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                    value={formData.oemReturnDate || ''}
                    onChange={(e) => setFormData({ ...formData, oemReturnDate: e.target.value })}
                  />
                </div>
              </div>

              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-4">
                <div className="flex items-center gap-2 mb-2">
                  <FileText size={16} className="text-blue-600" />
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">OEM Documentation</span>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <FileUploadField 
                    label="PO Details" 
                    numberField="poNumber" 
                    fileField="poFile" 
                    placeholder="PO-XXXX"
                    inputRef={poRef}
                  />
                  <FileUploadField 
                    label="Invoice" 
                    numberField="invoiceNumber" 
                    fileField="invoiceFile" 
                    placeholder="INV-XXXX"
                    inputRef={invRef}
                  />
                  <FileUploadField 
                    label="Challan" 
                    numberField="challanNumber" 
                    fileField="challanFile" 
                    placeholder="CH-XXXX"
                    inputRef={chaRef}
                  />
                </div>
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase">Description / Testing Notes</label>
            <textarea
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none h-24 resize-none"
              value={formData.description || ''}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Internal testing observations or incident details..."
            />
          </div>
        </form>

        <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
          <button onClick={onClose} className="px-6 py-2 text-slate-600 hover:text-slate-800 font-medium">Cancel</button>
          <button onClick={handleSubmit} className="px-8 py-2 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-500/20 transition-all">
            Save Asset Data
          </button>
        </div>
      </div>
    </div>
  );
};

export default AssetModal;
