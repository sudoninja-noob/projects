import React from 'react';
import { NAVIGATION_ITEMS } from '../constants';
import { User, Role } from '../types';
import { LogOut, User as UserIcon } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUser: User;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab, currentUser, onLogout }) => {
  const filteredNavItems = NAVIGATION_ITEMS.filter(item => 
    !item.roles || item.roles.includes(currentUser.role)
  );

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-72 bg-slate-900 text-white flex flex-col shadow-2xl z-20">
        <div className="p-8 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 shrink-0">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                <path d="M50 5 L85 20 L85 50 C85 75 50 95 50 95 C50 95 15 75 15 50 L15 20 Z" fill="#3b82f6" />
                <path d="M30 40 H70 M30 55 H55" stroke="white" strokeWidth="6" strokeLinecap="round" opacity="0.3" />
                <circle cx="50" cy="50" r="10" fill="white" />
              </svg>
            </div>
            <div className="overflow-hidden">
              <h1 className="font-black text-xl tracking-tighter text-white leading-none">TelcoSec</h1>
              <p className="text-[10px] text-blue-400 font-black uppercase tracking-widest truncate mt-1">Asset Guardian</p>
            </div>
          </div>
          <div className="h-px bg-white/5 mt-6 mb-2"></div>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1.5 overflow-y-auto">
          {filteredNavItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-200 group ${
                activeTab === item.id 
                ? 'bg-blue-600 text-white shadow-xl shadow-blue-500/20 translate-x-1' 
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <div className={activeTab === item.id ? 'text-white' : 'text-slate-500 group-hover:text-blue-400'}>
                {item.icon}
              </div>
              <span className="font-bold text-sm tracking-tight">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-white/5">
          <div className="bg-white/5 rounded-3xl p-5 mb-4 border border-white/5">
            <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-3">Auth Session</p>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center text-blue-400 border border-white/10 overflow-hidden shadow-inner">
                {currentUser.profilePic ? (
                  <img src={currentUser.profilePic} alt="" className="w-full h-full object-cover" />
                ) : (
                  <UserIcon size={24} />
                )}
              </div>
              <div className="overflow-hidden">
                <p className="text-sm font-bold truncate text-slate-100">{currentUser.name}</p>
                <div className="flex items-center gap-1.5 mt-1">
                   <div className={`w-1.5 h-1.5 rounded-full ${currentUser.role === Role.ADMIN ? 'bg-indigo-400' : 'bg-emerald-400 animate-pulse'}`}></div>
                   <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{currentUser.role.replace('_', ' ')}</p>
                </div>
              </div>
            </div>
          </div>
          
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-slate-800 hover:bg-red-500/20 hover:text-red-400 text-slate-400 rounded-2xl transition-all text-xs font-bold uppercase tracking-widest border border-white/5"
          >
            <LogOut size={16} />
            Secure Exit
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-20 bg-white border-b border-slate-100 flex items-center justify-between px-10 shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-slate-900 font-black text-lg tracking-tight">
              {filteredNavItems.find(n => n.id === activeTab)?.label}
            </span>
          </div>
          <div className="flex items-center gap-8">
            <div className="hidden md:block text-right">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">TelcoSec Node</p>
              <p className="text-sm font-bold text-slate-700">{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
            </div>
            <div className="h-10 w-px bg-slate-100 hidden md:block"></div>
            <div className="flex items-center gap-4">
               <span className="text-xs font-bold text-emerald-500 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">Auth Encrypted</span>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-10 bg-slate-50/30">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Layout;