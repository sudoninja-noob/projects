
import React, { useState } from 'react';
import { User, Role, SecurityQuestion } from '../types';
import { DEFAULT_SECURITY_QUESTIONS } from '../constants';
import { UserPlus, Trash2, ShieldCheck, UserCheck, Search, Edit2, X, Check, Lock, User as UserIcon, Camera, HelpCircle } from 'lucide-react';

interface StaffManagementProps {
  users: User[];
  onAddUser: (user: User) => void;
  onUpdateUser: (user: User) => void;
  onDeleteUser: (id: string) => void;
}

const StaffManagement: React.FC<StaffManagementProps> = ({ users, onAddUser, onUpdateUser, onDeleteUser }) => {
  const [formState, setFormState] = useState<{ isOpen: boolean; editingId: string | null }>({
    isOpen: false,
    editingId: null,
  });
  const [searchTerm, setSearchTerm] = useState('');
  
  const initialFormData = {
    name: '',
    username: '',
    password: '',
    role: Role.SECURITY_GUARD,
    profilePic: 'https://api.dicebear.com/7.x/avataaars/svg?seed=default',
    securityQuestions: Array(5).fill(0).map((_, i) => ({ 
      question: DEFAULT_SECURITY_QUESTIONS[i], 
      answer: '' 
    })) as SecurityQuestion[]
  };

  const [formData, setFormData] = useState(initialFormData);

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenAdd = () => {
    setFormData({ 
      ...initialFormData, 
      profilePic: `https://api.dicebear.com/7.x/avataaars/svg?seed=${Math.random()}` 
    });
    setFormState({ isOpen: true, editingId: null });
  };

  const handleOpenEdit = (user: User) => {
    setFormData({
      name: user.name,
      username: user.username,
      password: user.password,
      role: user.role,
      profilePic: user.profilePic || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username}`,
      securityQuestions: user.securityQuestions.length === 5 
        ? user.securityQuestions 
        : initialFormData.securityQuestions
    });
    setFormState({ isOpen: true, editingId: user.id });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.username.trim()) return;

    if (formState.editingId) {
      onUpdateUser({
        id: formState.editingId,
        ...formData
      } as User);
    } else {
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        ...formData
      } as User;
      onAddUser(newUser);
    }
    setFormState({ isOpen: false, editingId: null });
  };

  const updateQuestion = (index: number, field: keyof SecurityQuestion, value: string) => {
    const updated = [...formData.securityQuestions];
    updated[index] = { ...updated[index], [field]: value };
    setFormData({ ...formData, securityQuestions: updated });
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-2xl font-black text-slate-900 tracking-tight">Staff Management</h3>
          <p className="text-slate-500 text-sm font-medium">Configure secure access profiles for lab personnel</p>
        </div>
        <button 
          onClick={formState.isOpen ? () => setFormState({ ...formState, isOpen: false }) : handleOpenAdd}
          className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-bold shadow-xl transition-all active:scale-95 ${
            formState.isOpen 
            ? 'bg-slate-200 text-slate-700 hover:bg-slate-300 shadow-none' 
            : 'bg-indigo-600 text-white shadow-indigo-500/20 hover:bg-indigo-700'
          }`}
        >
          {formState.isOpen ? <X size={20} /> : <UserPlus size={20} />}
          <span>{formState.isOpen ? 'Cancel' : 'Register New User'}</span>
        </button>
      </div>

      {formState.isOpen && (
        <form onSubmit={handleSubmit} className="bg-white p-8 rounded-[2.5rem] border-2 border-indigo-100 shadow-2xl shadow-indigo-500/10 animate-in slide-in-from-top-4 duration-300 space-y-8">
          <div className="flex items-center justify-between border-b border-slate-100 pb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                {formState.editingId ? <Edit2 size={20} /> : <UserPlus size={20} />}
              </div>
              <h4 className="text-xl font-extrabold text-slate-800">
                {formState.editingId ? 'Update Staff Member' : 'System Registration'}
              </h4>
            </div>
            <div className="flex items-center gap-4">
              <img src={formData.profilePic} className="w-16 h-16 rounded-2xl border-2 border-indigo-200 bg-indigo-50" alt="Avatar" />
              <button 
                type="button" 
                onClick={() => setFormData({...formData, profilePic: `https://api.dicebear.com/7.x/avataaars/svg?seed=${Math.random()}`})}
                className="p-2 bg-slate-100 rounded-xl text-slate-600 hover:bg-indigo-600 hover:text-white transition-all"
                title="Randomize Avatar"
              >
                <Camera size={20} />
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Full Name</label>
              <input 
                type="text" 
                required
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-medium"
                placeholder="e.g. Robert Smith"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">System Username</label>
              <div className="relative">
                <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input 
                  type="text" 
                  required
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-medium"
                  placeholder="rsmith_lab"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Security Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input 
                  type="password" 
                  required
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-medium"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Access Tier</label>
              <select 
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 font-bold text-slate-700"
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value as Role })}
              >
                <option value={Role.SECURITY_GUARD}>Security Guard</option>
                <option value={Role.ADMIN}>Administrator</option>
              </select>
            </div>
          </div>

          <div className="bg-slate-50/50 p-6 rounded-3xl border border-slate-200 space-y-6">
            <div className="flex items-center gap-2 mb-2">
              <HelpCircle size={18} className="text-indigo-600" />
              <h5 className="text-sm font-black text-slate-800 uppercase tracking-widest">Account Recovery (5 Security Questions)</h5>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {formData.securityQuestions.map((sq, idx) => (
                <div key={idx} className="space-y-3 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black text-indigo-500 uppercase">Question {idx + 1}</span>
                  </div>
                  <select 
                    className="w-full p-2 text-xs bg-slate-50 border border-slate-100 rounded-lg focus:outline-none font-semibold text-slate-700"
                    value={sq.question}
                    onChange={(e) => updateQuestion(idx, 'question', e.target.value)}
                  >
                    {DEFAULT_SECURITY_QUESTIONS.map(q => <option key={q} value={q}>{q}</option>)}
                  </select>
                  <input 
                    type="text"
                    required
                    placeholder="Enter Secret Answer"
                    className="w-full px-3 py-2 text-sm bg-indigo-50/30 border border-indigo-100 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-300 font-medium"
                    value={sq.answer}
                    onChange={(e) => updateQuestion(idx, 'answer', e.target.value)}
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end pt-4">
            <button type="submit" className="flex items-center justify-center gap-2 px-10 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-500/20 active:scale-95">
              <Check size={20} />
              {formState.editingId ? 'Save Profile Changes' : 'Activate Staff Account'}
            </button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 bg-slate-50/50 border-b border-slate-100 flex flex-col md:flex-row justify-between gap-4">
          <div className="relative w-full max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Filter by name or username..." 
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 text-sm shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-4 text-xs font-bold text-slate-400 uppercase tracking-widest px-4">
            <span>Total Staff: {users.length}</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-200">
                <th className="px-8 py-5 text-xs font-bold text-slate-400 uppercase tracking-widest">Personnel</th>
                <th className="px-8 py-5 text-xs font-bold text-slate-400 uppercase tracking-widest">Auth Credentials</th>
                <th className="px-8 py-5 text-xs font-bold text-slate-400 uppercase tracking-widest">Access Level</th>
                <th className="px-8 py-5 text-xs font-bold text-slate-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-slate-50/30 transition-colors group">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-4">
                      <img src={user.profilePic || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username}`} className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 shadow-sm" alt="" />
                      <div>
                        <p className="font-bold text-slate-900 leading-tight">{user.name}</p>
                        <p className="text-[10px] text-slate-400 font-mono mt-0.5">ID: {user.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <UserIcon size={12} className="text-slate-300" />
                        <span className="text-sm font-semibold text-slate-700">@{user.username}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Lock size={12} className="text-slate-300" />
                        <span className="text-[10px] text-slate-400">Recovery Setup: {user.securityQuestions.length}/5</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider ${
                      user.role === Role.ADMIN ? 'bg-indigo-50 text-indigo-600 border border-indigo-100' : 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                    }`}>
                      {user.role.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => handleOpenEdit(user)}
                        className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all"
                        title="Edit Profile"
                      >
                        <Edit2 size={18} />
                      </button>
                      <button 
                        onClick={() => onDeleteUser(user.id)}
                        className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                        title="Revoke Access"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StaffManagement;
