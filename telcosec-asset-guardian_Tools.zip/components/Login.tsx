import React, { useState } from 'react';
import { Role, User, SecurityQuestion } from '../types';
import { Lock, User as UserIcon, AlertCircle, ChevronRight, HelpCircle, ArrowLeft, KeyRound, CheckCircle, ShieldCheck } from 'lucide-react';

interface LoginProps {
  onLogin: (user: User) => void;
  users: User[];
}

const Login: React.FC<LoginProps> = ({ onLogin, users }) => {
  const [view, setView] = useState<'login' | 'forgot' | 'recovery-question' | 'reset-password' | 'success'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [recoveryUser, setRecoveryUser] = useState<User | null>(null);
  const [randomQuestion, setRandomQuestion] = useState<SecurityQuestion | null>(null);
  const [recoveryAnswer, setRecoveryAnswer] = useState('');

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    setTimeout(() => {
      const foundUser = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password);
      
      if (foundUser) {
        onLogin(foundUser);
      } else {
        setError('Invalid credentials. Check your username/password.');
        setIsSubmitting(false);
      }
    }, 600);
  };

  const startRecovery = (e: React.FormEvent) => {
    e.preventDefault();
    const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());
    if (user && user.securityQuestions.length > 0) {
      setRecoveryUser(user);
      const randomQ = user.securityQuestions[Math.floor(Math.random() * user.securityQuestions.length)];
      setRandomQuestion(randomQ);
      setView('recovery-question');
    } else {
      setError('User not found in system database.');
    }
  };

  const verifyRecoveryAnswer = (e: React.FormEvent) => {
    e.preventDefault();
    if (randomQuestion && recoveryAnswer.toLowerCase().trim() === randomQuestion.answer.toLowerCase().trim()) {
      setView('reset-password');
      setError(null);
    } else {
      setError('Incorrect answer to security question.');
    }
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setView('success');
  };

  const resetFlow = () => {
    setView('login');
    setError(null);
    setUsername('');
    setPassword('');
    setRecoveryUser(null);
    setRecoveryAnswer('');
    setNewPassword('');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none">
        <ShieldCheck size={400} />
      </div>

      <div className="w-full max-w-md z-10">
        <div className="bg-white p-2 text-center flex flex-col items-center mb-8">
          <div className="flex flex-col items-center gap-4 mb-4">
            <div className="w-24 h-24 relative">
              <div className="absolute inset-0 bg-blue-600/10 rounded-full animate-ping duration-[3s]"></div>
              <svg viewBox="0 0 100 100" className="w-full h-full relative drop-shadow-xl">
                <defs>
                  <linearGradient id="shieldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style={{ stopColor: '#1e3a8a', stopOpacity: 1 }} />
                    <stop offset="100%" style={{ stopColor: '#1e293b', stopOpacity: 1 }} />
                  </linearGradient>
                </defs>
                {/* Shield Base */}
                <path d="M50 5 L85 20 L85 50 C85 75 50 95 50 95 C50 95 15 75 15 50 L15 20 Z" fill="url(#shieldGrad)" />
                {/* Decorative Circuits */}
                <path d="M30 35 H70 M30 50 H55 M30 65 H45" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" opacity="0.4" />
                <circle cx="70" cy="35" r="3" fill="#38bdf8" />
                <circle cx="55" cy="50" r="3" fill="#38bdf8" />
                <circle cx="45" cy="65" r="3" fill="#38bdf8" />
                {/* Central Keyhole/Circle */}
                <circle cx="50" cy="50" r="8" fill="white" />
                <path d="M50 50 L50 65" stroke="white" strokeWidth="4" strokeLinecap="round" />
              </svg>
            </div>
            <div className="text-center">
              <h1 className="text-3xl font-black text-slate-900 tracking-tight leading-none">TelcoSec</h1>
              <p className="text-lg font-bold text-blue-600 tracking-widest mt-1">Asset Guardian</p>
            </div>
          </div>
          <div className="h-px w-12 bg-slate-200 mt-4"></div>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.3em] mt-4">Telecom Security Testing Lab</p>
        </div>

        <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.1)] overflow-hidden transition-all duration-500">
          <div className="p-10">
            {error && (
              <div className="flex items-center gap-3 p-4 bg-red-50 border border-red-100 rounded-2xl text-red-600 text-sm font-medium mb-6 animate-in slide-in-from-top-2">
                <AlertCircle size={18} className="shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {view === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-5">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Secure Username</label>
                  <div className="relative">
                    <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input
                      type="text"
                      required
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-400 transition-all font-medium text-slate-900"
                      placeholder="Operator Name"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex justify-between items-center ml-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Master Key</label>
                    <button type="button" onClick={() => setView('forgot')} className="text-[10px] font-bold text-blue-600 hover:text-blue-800 uppercase tracking-widest">Recovery?</button>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input
                      type="password"
                      required
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-400 transition-all font-medium text-slate-900"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full flex items-center justify-center gap-3 py-4 bg-blue-900 text-white rounded-2xl font-bold shadow-2xl shadow-blue-900/20 hover:bg-blue-800 transition-all active:scale-[0.98] disabled:opacity-70 group mt-4"
                >
                  {isSubmitting ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <span>Unlock Terminal</span>
                      <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </button>
              </form>
            )}

            {view === 'forgot' && (
              <form onSubmit={startRecovery} className="space-y-6">
                <div className="text-center space-y-2 mb-4">
                  <KeyRound size={28} className="mx-auto text-blue-600" />
                  <h2 className="text-xl font-bold text-slate-800">Identify Account</h2>
                  <p className="text-sm text-slate-500">Validation required for key reset</p>
                </div>
                <div className="space-y-1.5">
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:outline-none focus:border-blue-500"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                </div>
                <button type="submit" className="w-full py-4 bg-blue-900 text-white rounded-2xl font-bold hover:bg-blue-800 transition-all">
                  Next Step
                </button>
                <button type="button" onClick={resetFlow} className="w-full flex items-center justify-center gap-2 text-sm font-bold text-slate-400 hover:text-slate-600 pt-2">
                  <ArrowLeft size={16} /> Back to Entry
                </button>
              </form>
            )}

            {view === 'recovery-question' && (
              <form onSubmit={verifyRecoveryAnswer} className="space-y-6">
                <div className="text-center space-y-2 mb-4">
                  <HelpCircle size={28} className="mx-auto text-blue-600" />
                  <h2 className="text-xl font-bold text-slate-800">Security Challenge</h2>
                  <p className="text-sm text-slate-500 italic">"{randomQuestion?.question}"</p>
                </div>
                <div className="space-y-1.5">
                  <input
                    type="text"
                    required
                    autoComplete="off"
                    className="w-full px-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:outline-none focus:border-blue-500"
                    placeholder="Your Answer"
                    value={recoveryAnswer}
                    onChange={(e) => setRecoveryAnswer(e.target.value)}
                  />
                </div>
                <button type="submit" className="w-full py-4 bg-blue-900 text-white rounded-2xl font-bold">
                  Confirm Answer
                </button>
                <button type="button" onClick={resetFlow} className="w-full text-sm font-bold text-slate-400">Abort Recovery</button>
              </form>
            )}

            {view === 'reset-password' && (
              <form onSubmit={handleResetPassword} className="space-y-6">
                <div className="text-center space-y-2 mb-4">
                  <CheckCircle size={28} className="mx-auto text-emerald-600" />
                  <h2 className="text-xl font-bold text-slate-800">Key Update</h2>
                </div>
                <div className="space-y-1.5">
                  <input
                    type="password"
                    required
                    className="w-full px-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:outline-none focus:border-emerald-500"
                    placeholder="New Password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                  />
                </div>
                <button type="submit" className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold">
                  Register New Key
                </button>
              </form>
            )}

            {view === 'success' && (
              <div className="text-center space-y-6 py-4">
                <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle size={48} className="text-emerald-500" />
                </div>
                <h2 className="text-2xl font-bold text-slate-900">Access Restored</h2>
                <button onClick={resetFlow} className="w-full py-4 bg-blue-900 text-white rounded-2xl font-bold">
                  Return to Portal
                </button>
              </div>
            )}
          </div>
        </div>
        
        <p className="text-center mt-12 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">
          &copy; 2025 TelcoSec Laboratory Infrastructure
        </p>
      </div>
    </div>
  );
};

export default Login;