
import React, { useState } from 'react';
import { Asset, AssetType, Role, AssetStatus, TestingStatus } from '../types';
import { STATUS_COLORS } from '../constants';
import { Search, Filter, Edit2, Trash2, ArrowRightLeft, Sparkles, AlertCircle, Paperclip, Clock, Calendar } from 'lucide-react';
import { getAssetIntelligence } from '../services/geminiService';

interface AssetTableProps {
  assets: Asset[];
  type: AssetType;
  userRole: Role;
  onEdit: (asset: Asset) => void;
  onDelete: (id: string) => void;
  onCheckInOut: (asset: Asset) => void;
  onStatusChange: (asset: Asset, status: AssetStatus) => void;
}

const AssetTable: React.FC<AssetTableProps> = ({ 
  assets, type, userRole, onEdit, onDelete, onCheckInOut, onStatusChange 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [aiAnalysis, setAiAnalysis] = useState<{id: string, text: string} | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);

  const filteredAssets = assets.filter(a => 
    a.type === type && 
    (a.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
     a.tag.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleAiDeepDive = async (asset: Asset) => {
    setLoadingAi(true);
    const text = await getAssetIntelligence(asset);
    setAiAnalysis({ id: asset.id, text });
    setLoadingAi(false);
  };

  const getDocCount = (asset: Asset) => {
    let count = 0;
    if (asset.poFile) count++;
    if (asset.invoiceFile) count++;
    if (asset.challanFile) count++;
    return count;
  };

  // Both Admin and Guard can now do everything with assets
  const canManageAssets = userRole === Role.ADMIN || userRole === Role.SECURITY_GUARD;

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search by tag, name..." 
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-colors">
            <Filter size={18} />
            <span>Filter</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Asset Info</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Category</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">
                  {type === AssetType.INTERNAL ? 'Assignee / Location' : 'OEM Tracking'}
                </th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAssets.map((asset) => {
                const docCount = getDocCount(asset);
                const hasStatusInfo = asset.statusDate || asset.statusTime;
                
                return (
                  <tr key={asset.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-bold text-slate-900">{asset.name}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <p className="text-xs text-slate-400 font-mono">{asset.tag}</p>
                          {docCount > 0 && (
                            <div className={`flex items-center gap-1 px-1.5 py-0.5 rounded border ${asset.type === AssetType.INTERNAL ? 'bg-indigo-50 border-indigo-100' : 'bg-blue-50 border-blue-100'}`}>
                              <Paperclip size={10} className={asset.type === AssetType.INTERNAL ? 'text-indigo-400' : 'text-blue-400'} />
                              <span className={`text-[10px] font-bold ${asset.type === AssetType.INTERNAL ? 'text-indigo-600' : 'text-blue-600'}`}>{docCount} Docs</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-slate-600">{asset.category}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="space-y-1.5">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${STATUS_COLORS[asset.status]}`}>
                          {asset.status.replace('_', ' ')}
                        </span>
                        {asset.type === AssetType.OEM && asset.testingStatus && (
                          <div className="flex items-center gap-1 mt-1">
                            <span className={`w-1.5 h-1.5 rounded-full ${asset.testingStatus === TestingStatus.PASS ? 'bg-green-500' : 'bg-amber-500'}`}></span>
                            <span className="text-[10px] text-slate-400 font-medium">Test: {asset.testingStatus}</span>
                          </div>
                        )}
                        {hasStatusInfo && (
                          <div className="flex items-center gap-2 text-[10px] text-slate-500 font-medium bg-slate-100 px-1.5 py-0.5 rounded w-fit">
                            {asset.statusDate && <div className="flex items-center gap-0.5"><Calendar size={10} /> {asset.statusDate}</div>}
                            {asset.statusTime && <div className="flex items-center gap-0.5"><Clock size={10} /> {asset.statusTime}</div>}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {type === AssetType.INTERNAL ? (
                        <div>
                          <p className="text-sm font-medium text-slate-700">{asset.assignedTo || 'Unassigned'}</p>
                          <p className="text-xs text-slate-400">{asset.location}</p>
                        </div>
                      ) : (
                        <div>
                          <p className="text-sm font-medium text-slate-700">{asset.oemName || 'Unknown OEM'}</p>
                          <p className="text-xs text-slate-400">Return Due: {asset.oemReturnDate || 'N/A'}</p>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button 
                          onClick={() => handleAiDeepDive(asset)}
                          title="AI Analysis"
                          className="p-2 text-indigo-500 hover:bg-indigo-50 rounded-lg transition-colors"
                        >
                          <Sparkles size={18} />
                        </button>
                        {canManageAssets && (
                          <>
                            <button 
                              onClick={() => onCheckInOut(asset)}
                              className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-colors"
                              title="Check In/Out"
                            >
                              <ArrowRightLeft size={18} />
                            </button>
                            <button onClick={() => onEdit(asset)} className="p-2 text-slate-400 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors">
                              <Edit2 size={18} />
                            </button>
                            <button onClick={() => onDelete(asset.id)} className="p-2 text-red-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors">
                              <Trash2 size={18} />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {aiAnalysis && (
        <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-xl flex gap-3 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <AlertCircle className="text-indigo-500 shrink-0 mt-0.5" size={20} />
          <div>
            <div className="flex justify-between items-start">
              <h5 className="font-bold text-indigo-900 text-sm">Compliance & Maintenance Advisory</h5>
              <button onClick={() => setAiAnalysis(null)} className="text-indigo-400 hover:text-indigo-600 text-xs">Dismiss</button>
            </div>
            <p className="text-indigo-800 text-xs mt-1 leading-relaxed">
              {loadingAi ? "Analyzing equipment specs..." : aiAnalysis.text}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default AssetTable;
