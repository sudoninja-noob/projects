
import React, { useMemo, useState, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import { Asset, AssetType, AssetStatus, AuditLogEntry } from '../types';
import { CATEGORIES } from '../constants';
import { Sparkles, Activity, AlertTriangle, CheckCircle2, Package, ShieldCheck, Filter, RotateCcw, Download, FileSpreadsheet, Loader2 } from 'lucide-react';
import { generateAuditSummary } from '../services/geminiService';
import JSZip from 'jszip';

interface DashboardProps {
  assets: Asset[];
  logs: AuditLogEntry[];
}

const Dashboard: React.FC<DashboardProps> = ({ assets, logs }) => {
  const [viewMode, setViewMode] = useState<AssetType>(AssetType.INTERNAL);
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [aiSummary, setAiSummary] = useState("Generating security posture analysis...");
  const [isBackingUp, setIsBackingUp] = useState<AssetType | null>(null);

  useEffect(() => {
    const fetchSummary = async () => {
      const summary = await generateAuditSummary(logs);
      setAiSummary(summary || "No recent activity to summarize.");
    };
    fetchSummary();
  }, [logs, viewMode]);

  useEffect(() => {
    setCategoryFilter('All');
    setStatusFilter('All');
  }, [viewMode]);

  const stats = useMemo(() => {
    let filtered = assets.filter(a => a.type === viewMode);
    
    if (categoryFilter !== 'All') {
      filtered = filtered.filter(a => a.category === categoryFilter);
    }
    
    if (statusFilter !== 'All') {
      filtered = filtered.filter(a => a.status === statusFilter);
    }

    const total = filtered.length;
    const inTesting = filtered.filter(a => a.status === AssetStatus.TESTING).length;
    const inward = filtered.filter(a => a.status === AssetStatus.INWARD).length;
    const maintenance = filtered.filter(a => a.status === AssetStatus.MAINTENANCE).length;
    
    const byStatus = filtered.reduce((acc: any, asset) => {
      acc[asset.status] = (acc[asset.status] || 0) + 1;
      return acc;
    }, {});

    const statusData = Object.entries(byStatus).map(([name, value]) => ({ name, value }));
    
    const categoryData = filtered.reduce((acc: any, asset) => {
      acc[asset.category] = (acc[asset.category] || 0) + 1;
      return acc;
    }, {});

    const categoryChartData = Object.entries(categoryData).map(([name, value]) => ({ name, value }));

    return { total, inTesting, inward, maintenance, statusData, categoryChartData };
  }, [assets, viewMode, categoryFilter, statusFilter]);

  const handleBackupExport = async (type: AssetType) => {
    setIsBackingUp(type);
    try {
      const filteredAssets = assets.filter(a => a.type === type);
      
      // Comprehensive A to Z Headers for Internal and OEM
      const headers = [
        "System ID",
        "Asset Tag",
        "Asset Name",
        "Type",
        "Category",
        "Location",
        "Status",
        "Assigned To",
        "Purchase Date",
        "Warranty Expiry",
        "Condition",
        "OEM Name",
        "PO Number",
        "Invoice Number",
        "Challan Number",
        "Testing Status",
        "Expected Return Date",
        "Last Status Date",
        "Last Status Time",
        "Description/Notes",
        "Has PO File",
        "Has Invoice File",
        "Has Challan File"
      ];

      const csvRows = filteredAssets.map(a => {
        const row = [
          a.id,
          a.tag,
          a.name,
          a.type,
          a.category,
          a.location,
          a.status,
          a.assignedTo || "N/A",
          a.purchaseDate || "N/A",
          a.warrantyExpiry || "N/A",
          a.condition,
          a.oemName || "N/A",
          a.poNumber || "N/A",
          a.invoiceNumber || "N/A",
          a.challanNumber || "N/A",
          a.testingStatus || "N/A",
          a.oemReturnDate || "N/A",
          a.statusDate || "N/A",
          a.statusTime || "N/A",
          a.description || "N/A",
          a.poFile ? "YES" : "NO",
          a.invoiceFile ? "YES" : "NO",
          a.challanFile ? "YES" : "NO"
        ];
        
        return row.map(val => `"${val.toString().replace(/"/g, '""')}"`).join(",");
      });

      const csvContent = [headers.join(","), ...csvRows].join("\n");

      // Generate Zip Archive
      const zip = new JSZip();
      const fileName = `GRL_Asset_Report_${type}_${new Date().toISOString().split('T')[0]}.csv`;
      zip.file(fileName, csvContent);

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(zipBlob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `GRL_FULL_BACKUP_${type}_${new Date().toISOString().split('T')[0]}.zip`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error("Backup failed", err);
    } finally {
      setIsBackingUp(null);
    }
  };

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#64748b', '#8b5cf6'];
  const currentCategories = viewMode === AssetType.INTERNAL ? CATEGORIES.INTERNAL : CATEGORIES.OEM;

  return (
    <div className="space-y-6">
      {/* Control Bar */}
      <div className="flex flex-col xl:flex-row gap-4 items-start xl:items-center justify-between">
        <div className="flex p-1.5 bg-slate-200 w-fit rounded-2xl shadow-inner">
          <button
            onClick={() => setViewMode(AssetType.INTERNAL)}
            className={`flex items-center gap-2 px-8 py-2.5 rounded-xl transition-all font-bold text-sm ${
              viewMode === AssetType.INTERNAL 
              ? 'bg-white text-blue-600 shadow-md' 
              : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Package size={18} />
            Internal Assets
          </button>
          <button
            onClick={() => setViewMode(AssetType.OEM)}
            className={`flex items-center gap-2 px-8 py-2.5 rounded-xl transition-all font-bold text-sm ${
              viewMode === AssetType.OEM 
              ? 'bg-white text-blue-600 shadow-md' 
              : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <ShieldCheck size={18} />
            OEM Devices
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full xl:w-auto">
          {/* Recovery and Backup Section */}
          <div className="flex items-center gap-2 p-1 bg-white rounded-2xl border border-slate-100 shadow-sm mr-2">
            <button
              onClick={() => handleBackupExport(AssetType.INTERNAL)}
              disabled={isBackingUp !== null}
              className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-700 rounded-xl text-xs font-black uppercase tracking-tight hover:bg-blue-100 transition-all group disabled:opacity-50"
            >
              {isBackingUp === AssetType.INTERNAL ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                <FileSpreadsheet size={14} className="group-hover:scale-110 transition-transform" />
              )}
              <span>A_Z Internal</span>
            </button>
            <button
              onClick={() => handleBackupExport(AssetType.OEM)}
              disabled={isBackingUp !== null}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-700 rounded-xl text-xs font-black uppercase tracking-tight hover:bg-indigo-100 transition-all group disabled:opacity-50"
            >
              {isBackingUp === AssetType.OEM ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                <Download size={14} className="group-hover:scale-110 transition-transform" />
              )}
              <span>A_Z OEM</span>
            </button>
          </div>

          <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm">
            <Filter size={14} className="text-slate-400" />
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Type:</span>
            <select 
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="text-sm font-bold text-slate-700 bg-transparent focus:outline-none cursor-pointer"
            >
              <option value="All">All Categories</option>
              {currentCategories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm">
            <Activity size={14} className="text-slate-400" />
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Live:</span>
            <select 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-sm font-bold text-slate-700 bg-transparent focus:outline-none cursor-pointer"
            >
              <option value="All">All Statuses</option>
              {Object.values(AssetStatus).map(status => (
                <option key={status} value={status}>{status.replace('_', ' ')}</option>
              ))}
            </select>
          </div>

          {(categoryFilter !== 'All' || statusFilter !== 'All') && (
            <button 
              onClick={() => { setCategoryFilter('All'); setStatusFilter('All'); }}
              className="p-2.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
              title="Clear Filter"
            >
              <RotateCcw size={18} />
            </button>
          )}
        </div>
      </div>

      {/* Top Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-7 rounded-3xl shadow-sm border border-slate-100 group hover:border-blue-200 transition-colors">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl group-hover:scale-110 transition-transform shadow-sm">
              <Activity size={24} />
            </div>
          </div>
          <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Matching Records</p>
          <h3 className="text-3xl font-black mt-1 text-slate-900">{stats.total}</h3>
          <p className="text-xs text-slate-400 mt-2 font-medium">Currently in system</p>
        </div>

        <div className="bg-white p-7 rounded-3xl shadow-sm border border-slate-100 group hover:border-amber-200 transition-colors">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl group-hover:scale-110 transition-transform shadow-sm">
              <Sparkles size={24} />
            </div>
          </div>
          <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Active Bench</p>
          <h3 className="text-3xl font-black mt-1 text-slate-900">{stats.inTesting}</h3>
          <p className="text-xs text-slate-400 mt-2 font-medium">Under active test/eval</p>
        </div>

        <div className="bg-white p-7 rounded-3xl shadow-sm border border-slate-100 group hover:border-green-200 transition-colors">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-green-50 text-green-600 rounded-2xl group-hover:scale-110 transition-transform shadow-sm">
              <CheckCircle2 size={24} />
            </div>
          </div>
          <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Registry Entry</p>
          <h3 className="text-3xl font-black mt-1 text-slate-900">{stats.inward}</h3>
          <p className="text-xs text-slate-400 mt-2 font-medium">Available for deployment</p>
        </div>

        <div className="bg-white p-7 rounded-3xl shadow-sm border border-slate-100 group hover:border-red-200 transition-colors">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-red-50 text-red-600 rounded-2xl group-hover:scale-110 transition-transform shadow-sm">
              <AlertTriangle size={24} />
            </div>
          </div>
          <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Sec Alert</p>
          <h3 className="text-3xl font-black mt-1 text-slate-900">{stats.maintenance}</h3>
          <p className="text-xs text-slate-400 mt-2 font-medium">Maintenance / Lost status</p>
        </div>
      </div>

      <div className="bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group border border-white/10">
        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:scale-125 transition-transform duration-1000">
          <FileSpreadsheet size={160} />
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center border border-white/20">
              <Sparkles className="text-blue-300" size={16} />
            </div>
            <h4 className="font-black uppercase tracking-[0.2em] text-[10px] text-blue-200">System Intelligence Node</h4>
          </div>
          <p className="text-blue-50 leading-relaxed text-sm max-w-4xl font-medium tracking-tight">
            {aiSummary}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
          <div className="flex justify-between items-center mb-8">
            <h4 className="font-black text-slate-900 tracking-tight text-lg">Category Distribution</h4>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.15em] bg-slate-100 px-3 py-1 rounded-full">{viewMode}</span>
          </div>
          <div className="h-[300px]">
            {stats.categoryChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.categoryChartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="name" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                    tick={{ fill: '#94a3b8', fontWeight: 700 }}
                  />
                  <YAxis 
                    fontSize={11} 
                    tickLine={false} 
                    axisLine={false} 
                    tick={{ fill: '#94a3b8', fontWeight: 600 }}
                  />
                  <Tooltip 
                    cursor={{ fill: '#f8fafc', radius: 8 }}
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', padding: '12px' }}
                  />
                  <Bar dataKey="value" fill="#2563eb" radius={[6, 6, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 italic text-sm font-medium">
                No matching categories in current filter set.
              </div>
            )}
          </div>
        </div>

        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
          <div className="flex justify-between items-center mb-8">
            <h4 className="font-black text-slate-900 tracking-tight text-lg">System Health Index</h4>
            <div className="flex gap-1.5">
               <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
               <div className="w-1.5 h-1.5 rounded-full bg-indigo-500"></div>
            </div>
          </div>
          <div className="h-[300px]">
            {stats.statusData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats.statusData}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={100}
                    paddingAngle={8}
                    dataKey="value"
                  >
                    {stats.statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} strokeWidth={0} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', padding: '12px' }}
                  />
                  <Legend 
                    layout="vertical" 
                    align="right" 
                    verticalAlign="middle" 
                    iconType="circle"
                    formatter={(value) => <span className="text-xs font-bold text-slate-600 uppercase tracking-wide">{value.replace('_', ' ')}</span>}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 italic text-sm font-medium">
                Insufficient data for distribution modeling.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
